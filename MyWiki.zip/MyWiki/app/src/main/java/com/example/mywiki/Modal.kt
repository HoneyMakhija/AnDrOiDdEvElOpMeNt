package com.example.mywiki

data class Modal(
    //var user:String,
    var url: String,
    var title: String = "",
    var description: String = "",
    var img_desc:String="",
    var cat:String=""
)