package com.example.mywiki

import com.google.gson.annotations.SerializedName
import org.json.JSONObject

data class Modal_result (
     val query: ArrayList<pages>,
//    val pages:JSONObject,
//     val pageid:Int,
    // val imageinfo:ArrayList<Modal>
)
