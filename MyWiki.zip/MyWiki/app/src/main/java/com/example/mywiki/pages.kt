package com.example.mywiki
data class pages (
    val k:ArrayList<key>

        )