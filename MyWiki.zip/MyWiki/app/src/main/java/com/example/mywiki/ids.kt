package com.example.mywiki

class ids (
    val id:Int
    )