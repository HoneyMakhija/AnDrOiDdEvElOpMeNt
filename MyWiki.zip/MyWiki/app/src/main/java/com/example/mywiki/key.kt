package com.example.mywiki

class key (
    val pageid:Int,
    val imageinfo:List<Modal>
    )